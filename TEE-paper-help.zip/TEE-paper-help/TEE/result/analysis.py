
import sys
import re
import openpyxl

import matplotlib.pyplot as plt
import matplotlib.pylab as mpl
import matplotlib.ticker as MultipleLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable
import numpy as np
import os
mpl.rcParams["font.family"] =  "Times New Roman" 
mpl.rcParams["mathtext.fontset"] = 'cm' 
mpl.rcParams["font.size"] = 10.5

rgb_limit0 = ['silver','gray']
rgb_limit1 = ['skyblue','steelblue']
rgb_limit2 = ['Khaki','Gold']
sur_param3 = ['*','-','/']
line_param3 = ['*','o']


wholeInst=1000000000
fileName='./testFinal02/505_rpreOnly.stats'
prefixList=['board.memory.mem_ctrl.Enc','board.memory.mem_ctrl.Mac',]
# case = ['525', '531', '541', '557', '507', '519', '526', '502', '520', '523', '505', 'bc-t', 'pr-t', 'cc-t', 'bc-w', 'pr-w', 'cc-w', 'dedup', 'ferret','fluidanimate', 'freqmine', 'splash2x.barnes', 'splash2x.radiosity','splash2x.raytrace']
# case_forP = ['525', '531', '541', '557', '507', '519', '526', '502', '520', '523', '505', 'bc-t', 'pr-t', 'cc-t', 'bc-w', 'pr-w', 'cc-w', 'P-ded', 'P-fer','P-flu', 'P-fre', 'S-bar', 'S-rad','S-ray','Avg.']
# case_full = ['525.x264', '531.deepsjeng', '541.leela', '557.xz', '507.cactuBSSN', '519.lbm', '526.blender', '502.gcc', '520.omnetpp', '523.xalancbmk', '505.mcf', 'bc-t', 'pr-t', 'cc-t', 'bc-w', 'pr-w', 'cc-w', 'dedup', 'ferret','fluidanimate', 'freqmine',  'splash2x.barnes', 'splash2x.radiosity','splash2x.raytrace']
case = ['525', '531', '541', '557', '507', '519', '526', '502', '520', '523', '505', 'bc-t', 'pr-t', 'cc-t', 'bc-w', 'pr-w', 'cc-w', 'dedup', 'ferret','fluidanimate','streamcluster','freqmine', 'splash2x.barnes', 'splash2x.radiosity','splash2x.raytrace']
case_forP = ['525', '531', '541', '557', '507', '519', '526', '502', '520', '523', '505', 'bc-t', 'pr-t', 'cc-t', 'bc-w', 'pr-w', 'cc-w', 'P-ded', 'P-fer','P-flu', 'P-str','P-fre', 'S-bar', 'S-rad','S-ray','Avg.']
case_full = ['525.x264', '531.deepsjeng', '541.leela', '557.xz', '507.cactuBSSN', '519.lbm', '526.blender', '502.gcc', '520.omnetpp', '523.xalancbmk', '505.mcf', 'bc-t', 'pr-t', 'cc-t', 'bc-w', 'pr-w', 'cc-w', 'dedup', 'ferret','fluidanimate', 'splash2x.barnes', 'splash2x.radiosity','splash2x.raytrace']
filePrefix='./testAllR1/'
filePrefix1='./testAllR1/'

filePrefixG4='./testAllR1-Group4/'
filePrefixG16='./testAllR1-Group16/'
filePrefixE6='./testAllR1-Entry6/'
filePrefixE8='./testAllR1-Entry8/'

filePrefixPDA='./testAllR1-PDA/'
filePrefixAPA='./testAllR1-APA/'

filePrefix4core='./testAllR1-4core/'
filePrefix2core='./testAllR1-2core/'
filePrefix8GB='./testAllR1-8G/'
filePrefix32GB='./testAllR1-32GB/'
printNow=False
# namePrefix=['Enc','Mac']
L2Miss = 'board.cache_hierarchy.l2cache.ReadSharedReq.misses::total'
L2MissLat = 'board.cache_hierarchy.l2cache.ReadSharedReq.missLatency::total'
L1Prefetch = 'board.cache_hierarchy.l2cache.ReadSharedReq.missLatency::cache_hierarchy.l1dcaches.prefetcher'

realTime = 'hostSeconds'

def getLineEnc(fileLines):
    findLine={}
    for line in fileLines:
        # print(line)
        for prefix in prefixList:
            lens=len(prefix)
            if line[0:lens] == prefix:
                if re.search(r'Enc\w+',line) != None:
                    match=re.search(r'Enc\w+',line)
                    name = match.group()
                elif re.search(r'Mac\w+',line) != None:
                    match=re.search(r'Mac\w+',line)
                    name = match.group()
                # vaule=re.findall(r"\b\d+\b",line)
                vaule=re.findall(r"\b\d+\.?\d+\b",line)
                # print(vaule)
                if len(vaule)!=0:
                    vaule=vaule[0]
                else:
                    vaule='0'
                findLine[name]=vaule
        if line[0:len(L2Miss)] == L2Miss:
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine['L2Miss'] = vaule[0]
        if line[0:len(L2MissLat)] == L2MissLat:
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine['L2MissLat'] = vaule[0]
        if line[0:len(L1Prefetch)] == L1Prefetch:
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine[L1Prefetch] = vaule[0]
        if line[0:len('simTicks')] == 'simTicks':
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine['simCycle'] = vaule[0]
        if line[0:len('simInsts')] == 'simInsts':
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine['simInst'] = vaule[0]
        if line[0:len('hostSeconds')] == 'hostSeconds':
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine['hostSeconds'] = vaule[0]
        if line[0:len('board.processor.cores.core.numLoadInsts')] == 'board.processor.cores.core.numLoadInsts':
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine['LoadInsts'] = vaule[0]
        if line[0:len('board.processor.cores.core.numInsts')] == 'board.processor.cores.core.numInsts':
            vaule=re.findall(r"\b\d+\.?\d+\b",line)
            findLine['numInsts'] = vaule[0]


    if printNow:
        print(findLine)
    return findLine

def Dic2List(findDic):
    nameList=[]
    valueList=[]
    for dic in findDic:
        nameList.append(dic)
        valueList.append(float(findDic[dic]))
    if printNow:
        print(nameList)
        print(valueList)
    return(nameList,valueList)

oriCycle=[]
VaultCycle=[]
PreVaultCycle=[]
readReq=[]
readAesPer=[]
readAes=[]
writeReq=[]
readHashAes=[]
writeHashAes=[]
macHitRate=[]
cntHitRate=[]
AllPreVaultCycle=[]
prefethTime=[]
prefethSuccessTime=[]
prefetchSuccessRate=[]
prefethSuccessAesMoreTime=[]


prefetchFullRate=[]
prefetchWaitRate=[]
prefetchTreeRate=[]
AESRate= []
AESRateOTPB= []

vaultOverhead=[]
OverheadCylec=[]
preOverhead=[]
AllpreOverhead=[]
# EncReadAllLatency
vaultReadL = []
preNoAesReadL = []
allReadL = []
# EncTreeNoCheck
noNeedTree = []

#memory traffic
DataTran = []
Cnt0Tran = []
Cnt1Tran = []
CntHTran = []
CntAll = []
MacAll = []
prefetchTran = []
overflowTran = []

#prefetch cycle
prefetchLat = []
GAPMem = []
remainHash = []

#reduce the percentage
saveAES = []
saveAESOTPB = []
SaveMAC = []

#aver
P1Avg = []
P3Avg = []
P4Avg = []

successPerAll = []
successPerAllOTPB = []
PrePer = []


#PT param
OverheadGroup4 = []
PrResGroup4 = []
PrOTPBGroup4 = []
OverheadGroup8 = []
PrResGroup8 = []
PrOTPBGroup8 = []
OverheadGroup16 = []
PrResGroup16 = []
PrOTPBGroup16 = []
OverheadEntry4 = []
PrResEntry4 = []
PrOTPBEntry4 = []
OverheadEntry6 = []
PrResEntry6 = []
PrOTPBEntry6 = []
OverheadEntry8 = []
PrResEntry8 = []
PrOTPBEntry8 = []

## APA PDA
APACycle = []
PDACycle = []

## 4core or 2 core
Inst4coreVault = []
Inst4corePre = []
Inst4corePreNoAES = []
ReadingFreq4core = []
WritingFreq4core = []

Inst2coreVault = []
Inst2corePre = []
Inst2corePreNoAES = []
ReadingFreq2core = []
WritingFreq2core = []


# 8GB 32GB configuration
Vault8gb = []
Pre8gb = []
PrenoAES8gb= []
ReadingFreq8gb= []
WritingFreq8gb= []

Vault32gb = []
Pre32gb = []
PrenoAES32gb= []
ReadingFreq32gb= []
WritingFreq32gb= []


PrRes4core= []
PrOTPB4core= []
PrRes2core= []
PrOTPB2core= []
PrRes8gb= []
PrOTPB8gb= []
PrRes32gb= []
PrOTPB32gb= []

InstNum = []
LoadInsts = []

def getPerformance(outFile='', PTen = False, alen = False):
    totalPCtime = 0
    totalPCtime_4core = 0
    totalPCtime_2core = 0
    for cs in case:
        fileN = filePrefix+cs+'_ori.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        # oriCycle.append(dicFind['EncTotTime'])
        oriCycle.append(float(dicFind['simCycle'])/500)
        # oriC = float(dicFind['EncTotTime'])
        oriC = float(dicFind['simCycle'])/500
        file.close()

        fileN = filePrefix+cs+'_vault.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        if cs == 'streamcluster':
            VaultCycle.append(float(dicFind['simCycle'])/500)
            vaultC = float(dicFind['simCycle'])/500
        else:
            VaultCycle.append(dicFind['EncTotTime'])
            vaultC = float(dicFind['EncTotTime'])
        readReq.append(float(dicFind['EncReadReq']))
        writeReq.append(float(dicFind['EncWriteReq']))
        readHashAes.append( float(dicFind['EncReadAesBias']) + float(dicFind['EncHashOverlapRDMAC']) )
        readAes.append( float(dicFind['EncReadAesBias']) )
        writeHashAes.append(float(dicFind['EncWriteHashTime']))
        macHitRate.append(float(dicFind['MacCache_hitRate']))
        cntHitRate.append(float(dicFind['EncCache_hitRate']))
        # vaultReadL.append(float(dicFind['L2MissLat'])/float(dicFind['L2Miss'])/1000)
        vaultReadL.append(float(dicFind['EncReadAllLatency'])/float(dicFind['EncReadReq'])/2)
        noNeedTree.append(float(dicFind['EncTreeNoCheck'])*100/float(dicFind['EncReadReq']))

        LoadInsts.append(float(dicFind['LoadInsts']))
        InstNum.append(float(dicFind['numInsts']))

        if float(dicFind['EncWriteReq']) != 0:
            P1Avg.append(float(dicFind['EncWriteHashTime'])/ float(dicFind['EncWriteReq'])/2)
        else:
            P1Avg.append(0)
        P3Avg.append(40 - float(dicFind['EncReadAesBias'])/ float(dicFind['EncReadReq'])/2)
        P4Avg.append(40 - float(dicFind['EncHashOverlapRDMAC']) / float(dicFind['EncReadReq'])/2)


        GAPMem.append(float(dicFind['EncAvgTotGap'])/2)
        remainHash.append(float(dicFind['EncHashOverlapRDMAC'])/float(dicFind['EncReadReq'])/2)

        vaultReadHashC = float(dicFind['EncHashOverlapRDMAC'])
        vaultReadAesC = float(dicFind['EncReadAesBias'])
        file.close()

        fileN = filePrefix1+cs+'_rpreOnly.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        totalPCtime = totalPCtime + float(dicFind['hostSeconds'])
        if cs == 'streamcluster':
            PreVaultCycle.append(float(dicFind['simCycle'])/500)
        else:
            PreVaultCycle.append(dicFind['EncTotTime'])
        a1 = float(dicFind['EncPrefetchTime'])
        a2 = float(dicFind['EncPreWaitCaled'])
        a3 = float(dicFind['EncPredictionSuccess'])
        atree = float(dicFind['EncPredictionSuccessTree'])
        prefethTime.append(a1)
        prefethSuccessTime.append(a2+a3)
        prefetchSuccessRate.append((a2+a3)/a1)
        prefetchFullRate.append(a3*100/a1)
        prefetchWaitRate.append(a2*100/a1)
        prefetchTreeRate.append(atree*100/a1)
        prefethSuccessAesMoreTime.append(float(dicFind['EncPredictionAesSuccess']))
        AESRate.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
        allReadL.append(float(dicFind['EncReadAllLatency'])/float(dicFind['EncReadReq'])/2)

        #memory tran
        DataTran.append(float(dicFind['EncReadReq']) + float(dicFind['EncWriteReq']))
        Cnt0Tran.append(float(dicFind['EncTreeL0MissTime']) + float(dicFind['EncWTreeL0MissTime']))
        Cnt1Tran.append(float(dicFind['EncTreeL1MissTime']) + float(dicFind['EncWTreeL1MissTime']))
        CntHTran.append(float(dicFind['EncTreeL2MissTime']) + float(dicFind['EncWTreeL2MissTime']) + float(dicFind['EncTreeL3MissTime']) + float(dicFind['EncWTreeL3MissTime']) + float(dicFind['EncTreeL4MissTime']) + float(dicFind['EncWTreeL4MissTime']))
        overflowTran.append(float(dicFind['EncReset_Mem_WrTime']) + float(dicFind['EncReset_Mem_RdTime']) )
        prefetchTran.append(float(dicFind['EncPrefetchTime']))
        CntAll.append(float(dicFind['EncCacheRd'])-float(dicFind['EncCacheRd_hit']) + float(dicFind['EncCacheWr'])-float(dicFind['EncCacheWr_hit']))
        MacAll.append(float(dicFind['MacCacheRd'])-float(dicFind['MacCacheRd_hit']) + float(dicFind['MacCacheWr'])-float(dicFind['MacCacheWr_hit']))
        prefetchLat.append(float(dicFind['EncPrefetchCycle'])/float(dicFind['EncPrefetchTime'])/2)
        

        SaveMAC.append(100- (float(dicFind['EncHashOverlapRDMAC'])*100 / vaultReadHashC))
        rOnlyAES= float(dicFind['EncPredictionSaveAes'])
        successPerAll.append((a2+a3+atree)*100/float(dicFind['EncReadReq']))
        successPerAllOTPB.append(float(dicFind['EncPredictionAesSuccess'])*100/float(dicFind['EncReadReq']))
        PrePer.append((a1)*100/float(dicFind['EncReadReq']))

        if cs == 'streamcluster':
            OverheadGroup8.append(vaultC*500/float(dicFind['simCycle']))
            OverheadEntry4.append(vaultC*500/float(dicFind['simCycle']))
        else:
            OverheadGroup8.append(vaultC/float(dicFind['EncTotTime']))
            OverheadEntry4.append(vaultC/float(dicFind['EncTotTime']))
        PrResGroup8.append((a2+a3+atree)*100/a1)
        PrResEntry4.append((a2+a3+atree)*100/a1)
        PrOTPBEntry4.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
        PrOTPBGroup8.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)


        file.close()
    
        fileN = filePrefix+cs+'_rpreOnlyNoAes.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        if cs == 'streamcluster':
            AllPreVaultCycle.append(float(dicFind['simCycle'])/500)
        else:
            AllPreVaultCycle.append(dicFind['EncTotTime'])
        preNoAesReadL.append(float(dicFind['EncReadAllLatency'])/float(dicFind['EncReadReq'])/2)


        rOnlyNoAES=float(dicFind['EncPredictionSaveAes'])
        saveAESOTPB.append( (((rOnlyAES- rOnlyNoAES)*100)/vaultReadAesC))
        saveAES.append( (rOnlyNoAES*100 / vaultReadAesC))
        file.close()


        ## get 4 core inst
        fileN = filePrefix4core+cs+'_4core_vault.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        ReadingFreq4core.append(float(dicFind['EncReadReq'])*1000/float(dicFind['simInst']))
        WritingFreq4core.append(float(dicFind['EncWriteReq'])*1000/float(dicFind['simInst']))
        Inst4coreVault.append(float(dicFind['simInst'])/float(dicFind['EncTotTime']))

        totalPCtime_4core = totalPCtime_4core + float(dicFind['hostSeconds'])
        file.close()


        fileN = filePrefix4core+cs+'_4core_rpreOnlyNoAes.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        Inst4corePreNoAES.append(float(dicFind['simInst'])/float(dicFind['EncTotTime']))

        totalPCtime_4core = totalPCtime_4core + float(dicFind['hostSeconds'])
        file.close()

        fileN = filePrefix4core+cs+'_4core_rpreOnly.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        Inst4corePre.append(float(dicFind['simInst'])/float(dicFind['EncTotTime']))

        a1 = float(dicFind['EncPrefetchTime'])
        a2 = float(dicFind['EncPreWaitCaled'])
        a3 = float(dicFind['EncPredictionSuccess'])
        atree = float(dicFind['EncPredictionSuccessTree'])
        PrRes4core.append((a2+a3+atree)*100/a1)
        PrOTPB4core.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)


        totalPCtime_4core = totalPCtime_4core + float(dicFind['hostSeconds'])
        file.close()

        ## get 2 core inst
        fileN = filePrefix2core+cs+'_2core_vault.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        ReadingFreq2core.append(float(dicFind['EncReadReq'])*1000/float(dicFind['simInst']))
        WritingFreq2core.append(float(dicFind['EncWriteReq'])*1000/float(dicFind['simInst']))
        Inst2coreVault.append(float(dicFind['EncTotInst'])/float(dicFind['EncTotTime']))

        totalPCtime_2core = totalPCtime_2core + float(dicFind['hostSeconds'])
        file.close()

        fileN = filePrefix2core+cs+'_2core_rpreOnlyNoAes.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        Inst2corePreNoAES.append(float(dicFind['EncTotInst'])/float(dicFind['EncTotTime']))

        totalPCtime_2core = totalPCtime_2core + float(dicFind['hostSeconds'])
        file.close()

        fileN = filePrefix2core+cs+'_2core_rpreOnly.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        Inst2corePre.append(float(dicFind['EncTotInst'])/float(dicFind['EncTotTime']))
        a1 = float(dicFind['EncPrefetchTime'])
        a2 = float(dicFind['EncPreWaitCaled'])
        a3 = float(dicFind['EncPredictionSuccess'])
        atree = float(dicFind['EncPredictionSuccessTree'])
        PrRes2core.append((a2+a3+atree)*100/a1)
        PrOTPB2core.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)


        totalPCtime_2core = totalPCtime_2core + float(dicFind['hostSeconds'])
        file.close()

        ## 8GB and 32GB
        fileN = filePrefix8GB+cs+'_8GB_vault.stats'
        if os.path.exists(fileN):
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            ReadingFreq8gb.append(float(dicFind['EncReadReq'])*1000/wholeInst)
            WritingFreq8gb.append(float(dicFind['EncWriteReq'])*1000/wholeInst)
            Vault8gb.append(float(dicFind['EncTotTime']))
            file.close()

        fileN = filePrefix8GB+cs+'_8GB_rpreOnly.stats'
        if os.path.exists(fileN):
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            Pre8gb.append(float(dicFind['EncTotTime']))
            a1 = float(dicFind['EncPrefetchTime'])
            a2 = float(dicFind['EncPreWaitCaled'])
            a3 = float(dicFind['EncPredictionSuccess'])
            atree = float(dicFind['EncPredictionSuccessTree'])
            PrRes8gb.append((a2+a3+atree)*100/a1)
            PrOTPB8gb.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
            file.close()

        fileN = filePrefix32GB+cs+'_32G_vault.stats'
        if os.path.exists(fileN):
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            ReadingFreq32gb.append(float(dicFind['EncReadReq'])*1000/wholeInst)
            WritingFreq32gb.append(float(dicFind['EncWriteReq'])*1000/wholeInst)
            Vault32gb.append(float(dicFind['EncTotTime']))
            file.close()
        fileN = filePrefix32GB+cs+'_32G_rpreOnly.stats'
        file = open(fileN,'r')
        lines = file.readlines()
        dicFind = getLineEnc(lines)
        Pre32gb.append(float(dicFind['EncTotTime']))
        a1 = float(dicFind['EncPrefetchTime'])
        a2 = float(dicFind['EncPreWaitCaled'])
        a3 = float(dicFind['EncPredictionSuccess'])
        atree = float(dicFind['EncPredictionSuccessTree'])
        PrRes32gb.append((a2+a3+atree)*100/a1)
        PrOTPB32gb.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
        file.close()

        ## PT param
        if PTen:
            fileN = filePrefixG4+cs+'_rpreOnly.stats'
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            a1 = float(dicFind['EncPrefetchTime'])
            a2 = float(dicFind['EncPreWaitCaled'])
            a3 = float(dicFind['EncPredictionSuccess'])
            atree = float(dicFind['EncPredictionSuccessTree'])
            if cs == 'streamcluster':
                OverheadGroup4.append(vaultC*500/float(dicFind['simCycle']))
            else:
                OverheadGroup4.append(vaultC/float(dicFind['EncTotTime']))
            PrResGroup4.append((a2+a3+atree)*100/a1)
            PrOTPBGroup4.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
            file.close()

            fileN = filePrefixG16+cs+'_rpreOnly.stats'
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            a1 = float(dicFind['EncPrefetchTime'])
            a2 = float(dicFind['EncPreWaitCaled'])
            a3 = float(dicFind['EncPredictionSuccess'])
            atree = float(dicFind['EncPredictionSuccessTree'])
            if cs == 'streamcluster':
                OverheadGroup16.append(vaultC*500/float(dicFind['simCycle']))
            else:
                OverheadGroup16.append(vaultC/float(dicFind['EncTotTime']))
            PrResGroup16.append((a2+a3+atree)*100/a1)
            PrOTPBGroup16.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
            file.close()

            fileN = filePrefixE6+cs+'_rpreOnly.stats'
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            a1 = float(dicFind['EncPrefetchTime'])
            a2 = float(dicFind['EncPreWaitCaled'])
            a3 = float(dicFind['EncPredictionSuccess'])
            atree = float(dicFind['EncPredictionSuccessTree'])
            if cs == 'streamcluster':
                OverheadEntry6.append(vaultC*500/float(dicFind['simCycle']))
            else:
                OverheadEntry6.append(vaultC/float(dicFind['EncTotTime']))
            PrResEntry6.append((a2+a3+atree)*100/a1)
            PrOTPBEntry6.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
            file.close()

            fileN = filePrefixE8+cs+'_rpreOnly.stats'
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            a1 = float(dicFind['EncPrefetchTime'])
            a2 = float(dicFind['EncPreWaitCaled'])
            a3 = float(dicFind['EncPredictionSuccess'])
            atree = float(dicFind['EncPredictionSuccessTree'])
            if cs == 'streamcluster':
                OverheadEntry8.append(vaultC*500/float(dicFind['simCycle']))
            else:
                OverheadEntry8.append(vaultC/float(dicFind['EncTotTime']))
            PrResEntry8.append((a2+a3+atree)*100/a1)
            PrOTPBEntry8.append(float(dicFind['EncPredictionAesSuccess'])*100/a1)
            file.close()


        ### PDA and APA ###
        if alen:
            fileN = filePrefixPDA+cs+'_rpreOnly.stats'
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            if cs == 'streamcluster':
                PDACycle.append(float(dicFind['simCycle'])/500)
            else:
                PDACycle.append(dicFind['EncTotTime'])
            file.close()

            fileN = filePrefixAPA+cs+'_rpreOnly.stats'
            file = open(fileN,'r')
            lines = file.readlines()
            dicFind = getLineEnc(lines)
            if cs == 'streamcluster':
                APACycle.append(float(dicFind['simCycle'])/500)
            else:
                APACycle.append(dicFind['EncTotTime'])
            file.close()


    
    readHashAesPer=[]
    writeHashAesPer=[]
    MemPer=[]
    for i in range(len(oriCycle)):
        vaultOverheadCylec = float(VaultCycle[i])-float(oriCycle[i])
        OverheadCylec.append(vaultOverheadCylec)
        vaultOverhead.append( (float(VaultCycle[i])-float(oriCycle[i]))/float(oriCycle[i]))
        preOverhead.append( (float(PreVaultCycle[i])-float(oriCycle[i]))/float(oriCycle[i]))
        AllpreOverhead.append( (float(AllPreVaultCycle[i])-float(oriCycle[i]))/float(oriCycle[i]))
        readHashAesPer.append(readHashAes[i]/vaultOverheadCylec)
        writeHashAesPer.append(writeHashAes[i]/vaultOverheadCylec)
        MemPer.append(1-(readHashAes[i]/vaultOverheadCylec)-(writeHashAes[i]/vaultOverheadCylec))
        readAesPer.append(readAes[i]/vaultOverheadCylec)

    print(oriCycle)
    print(VaultCycle)
    print(PreVaultCycle)
    print(vaultOverhead)
    print(preOverhead)

    print("==============>>> all case TIME: "+str(totalPCtime/3600) + " hours")
    print("==============>>> all 4 cores TIME: "+str(totalPCtime_4core/3600) + " hours")

    if(len(outFile) != 0):
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        case.insert(0,'CaseName')
        vaultOverhead.insert(0,'Vault')
        preOverhead.insert(0,'PredictionVault')
        AllpreOverhead.insert(0,'WithWrite')
        prefetchSuccessRate.insert(0,'Prefetch HitRate')

        readHashAesPer.insert(0,'readHashAesOverhead')
        writeHashAesPer.insert(0,'writeHashAesOveread')
        MemPer.insert(0,'AdditionalMemOverhead')
        macHitRate.insert(0,'macHitrate')
        cntHitRate.insert(0,'counterHitrate')
        readReq.insert(0,'ReadReq')
        writeReq.insert(0,'WriteReq')
        readAesPer.insert(0,'ReadAesOverhead')
        prefethSuccessAesMoreTime.insert(0,'AesMoreSuccess')
        prefethSuccessTime.insert(0,'HashSuccessTime')
        sheet.append(case)
        sheet.append(vaultOverhead)
        sheet.append(preOverhead)
        sheet.append(prefetchSuccessRate)
        # sheet.append(AllpreOverhead)
        sheet.append(readReq)
        sheet.append(writeReq)
        sheet.append(readHashAesPer)
        sheet.append(writeHashAesPer)
        sheet.append(MemPer)
        sheet.append(readAesPer)
        sheet.append(prefethSuccessTime)
        sheet.append(prefethSuccessAesMoreTime)
        sheet.append(macHitRate)
        sheet.append(cntHitRate)


        vaultNormal = [float(a)/float(b) for a,b in zip(VaultCycle,oriCycle)]
        preNoAesNormal = [float(a)/float(b) for a,b in zip(AllPreVaultCycle,oriCycle)]
        AllNormal = [float(a)/float(b) for a,b in zip(PreVaultCycle,oriCycle)]
        addAvg(vaultNormal)
        addAvg(preNoAesNormal)
        addAvg(AllNormal)
        improveOver1 = [(a-b)/a for a,b in zip(vaultNormal,preNoAesNormal)]
        improveOver2 = [(a-b)/a for a,b in zip(vaultNormal,AllNormal)]
        vaultNormal.insert(0,'normalVaul')
        preNoAesNormal.insert(0,'noAes')
        AllNormal.insert(0,'All')
        improveOver1.insert(0,"impRate1")
        improveOver2.insert(0,"impRate2")
        sheet.append(vaultNormal)
        sheet.append(preNoAesNormal)
        sheet.append(AllNormal)
        sheet.append(improveOver1)
        sheet.append(improveOver2)


        workbook.save(outFile)

def getCaseOverhead(caseName):
    fileN = filePrefix+caseName+'_ori.stats'
    file = open(fileN,'r')
    lines = file.readlines()
    dicFind = getLineEnc(lines)
    oriCycle=dicFind['EncTotTime']
    file.close()

    fileN = filePrefix+caseName+'_vault.stats'
    file = open(fileN,'r')
    lines = file.readlines()
    dicFind = getLineEnc(lines)
    vaultCycle=dicFind['EncTotTime']
    file.close()

    fileN = filePrefix+caseName+'_rpreOnly.stats'
    file = open(fileN,'r')
    lines = file.readlines()
    dicFind = getLineEnc(lines)
    preCycle=dicFind['EncTotTime']
    file.close()

    fileN = filePrefix+caseName+'_rpreOnlyNoAes.stats'
    file = open(fileN,'r')
    lines = file.readlines()
    dicFind = getLineEnc(lines)
    allpreCycle=dicFind['EncTotTime']
    file.close()

    vaultOverhead = (float(vaultCycle) - float(oriCycle))/float(oriCycle)
    preOverhead = (float(preCycle) - float(oriCycle))/float(oriCycle)
    allpreOverhead = (float(allpreCycle) - float(oriCycle))/float(oriCycle)
    print(vaultOverhead)
    print(preOverhead)
    print(allpreOverhead)


def addAvg(needAdd):
    sum = 0
    print(needAdd)
    for i in needAdd:
        sum = sum+i

    needAdd.append(sum/len(needAdd))
    return 

def drawOverheadIdentify():
    # fig = plt.figure(figsize=(10,5))
    fig = plt.figure(figsize=(10,3.5))
    ax = plt.gca()
    ax2 = ax.twinx()
    x_w = range(0,len(case)+1)
    getPerformance()
    P4Cycle = np.subtract(readHashAes,readAes)
    P3Cycle = readAes
    P2Cycle = writeHashAes
    tmp = np.subtract(OverheadCylec,readHashAes)
    memOpCycle = np.subtract(tmp,P2Cycle)
    memOpC=[]
    for i in memOpCycle:
        if i < 0:
            memOpC.append(0)
        else:
            memOpC.append(i)

    allC = (np.array(P3Cycle)+np.array(P2Cycle)+np.array(P4Cycle)+np.array(memOpC)).tolist()
    
            
    # print(memOpCycle)
    P4per = [a/b*100 for a,b in zip(P4Cycle,allC)]
    P3per = [a/b*100 for a,b in zip(P3Cycle,allC)]
    P2per = [a/b*100 for a,b in zip(P2Cycle,allC)]
    memOpPer = [a/b*100 for a,b in zip(memOpC,allC)]

    writeFreq = [a*1000/wholeInst for a in writeReq]
    readFreq = [a*1000/wholeInst for a in readReq]

    addAvg(P2per)
    addAvg(P3per)
    addAvg(P4per)
    addAvg(memOpPer)

    addAvg(writeFreq)
    addAvg(readFreq)

    print(P2per)
    print(P3per)
    print(P4per)
    print(memOpPer)
    print(writeFreq)
    print(readFreq)

    P3perG = P3per[:16]
    P4perG = P4per[:16]
    PPTo = [a + b for a,b in zip(P3perG,P4perG)]
    addAvg(PPTo)
    print("Genral Average: "+ str(PPTo[-1]))

    PPTo = [a + b for a,b in zip(P3per[17:-1],P4per[17:-1])]
    readFHPC = readFreq[17:-1]
    writeFHPC = writeFreq[17:-1]
    addAvg(readFHPC)
    addAvg(writeFHPC)
    addAvg(PPTo)
    print("memRead: ")
    print(case_forP[17:-1])
    print(readFHPC)
    print("memWrite: ")
    print(writeFHPC)
    print("P3+P4: ")
    print(PPTo)
    # non-liner
    readFreq_dra= [a-40 if a>70 else a for a in readFreq]
    writeFreq_dra = [a-40 if a>70 else a for a in writeFreq]


    bot0 = P2per
    bot1 = np.add(bot0,P3per)
    bot2 = np.add(bot1,P4per)

    xw1 = [a for a in x_w]
    ax.set_xlim(-0.5,len(case)+0.5)
    # xw1[len(case)] = xw1[len(case)] - 0.1
    xw2 = [a + 0.15 for a in x_w]
    # l1 = ax.bar(x_w,P2per,width=0.2, color = rgb_limit[0],ec='k',lw=1.5)
    # l2 = ax.bar(x_w,P3per,width=0.2,color = 'white',ec='k',bottom = bot0,lw=1.5)
    # l3 = ax.bar(x_w,P4per,width=0.2,color = 'white',ec='k',bottom = bot1,lw=1.5)
    l1 = ax.bar(xw1,P2per,width=0.5, color = 'white',ec='k',lw=1.5)
    l2 = ax.bar(xw1,P3per,width=0.5, color = rgb_limit0[0],ec='k',bottom = bot0,lw=1.5)
    l3 = ax.bar(xw1,P4per,width=0.5, color = rgb_limit0[1],ec='k',bottom = bot1,lw=1.5)
    l4 = ax.bar(xw1,memOpPer,width=0.5, color = 'white',ec='k', hatch='\\'*2,bottom = bot2,lw=1.5)

    ax2.plot(xw1,readFreq, color='black',marker='s',markersize=6,markerfacecolor='white',linestyle='--',lw=1.2)
    ax2.plot(xw1,writeFreq, color='black',marker='o',markersize=5,markerfacecolor='black',linestyle='--',lw=1.2)
    # l5 = ax2.bar(xw2,readFreq,width=0.3, color='white', ec='k',lw=1.5)
    # l6 = ax2.bar(xw2,writeFreq,width=0.3, color='white', hatch='/'*4,ec='k', bottom=readFreq,lw=1.5)

    case.append('Avg.')
    case_full.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=40,fontsize=16)
    ax.set_ylabel('Performance\nOverhead Breakdown (%)',fontsize=19)
    ax.set_ylim(0,100)
    ax.set_yticks([0,10,20,30,40,50,60,70,80,90,100])
    ax.tick_params(labelsize=15)

    ax2.set_ylabel('Memory Access Freq.\n(# /1k Instructions)',fontsize=19)
    ax2.set_ylim(-10,90)
    ax2.set_yticks([0,10,20,30,40,50,60,70,80,90])
    ax2.tick_params(labelsize=15)

    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)

    l11 = ax.legend((l1,l4,l2,l3),['P.1','Additional Mem.','P.3 OTP-compute','P.4 Hash-compute'],
            loc='upper right',bbox_to_anchor=(0.7,1.4),ncol=2,fontsize=15, title='Y-Left',title_fontsize=13)
    # ax.add_artist(l11)
    l11 = ax2.legend(['Read Freq.','Write Freq.'],
            loc='upper right',bbox_to_anchor=(1,1.4),ncol=1,fontsize=15,title='Y-Right',title_fontsize=13)
    # ax2.add_artist(l11)




    ax.grid(linestyle = "--", axis="y")
    plt.savefig('overheadAly.pdf',dpi=600, bbox_inches='tight')
    plt.show()


def drawNoTree():
    # plt.figure(figsize=(10,2.1))
    fig = plt.figure(figsize=(10,1.5))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    
    getPerformance()

    addAvg(noNeedTree)

    print(noNeedTree)

    w = 0.5
    ax.set_xlim(-0.5,len(case)+w)
    xw1 = [a for a in x_w]
    l1 = ax.bar(xw1,noNeedTree,width=w, color = rgb_limit0[0],ec='k',lw=1.5)

    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=35,fontsize=15)
    ax.set_ylabel('Only MAC\nPercentage',fontsize=15)
    ax.set_ylim(20,100)
    # ax.set_xlim(-w,len(case)-2*w)
    ax.tick_params(labelsize=15)

    plt.yticks([20,40,60,80,100])


    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")
    plt.savefig('noTree.pdf',dpi=600, bbox_inches='tight')
    plt.show()

def drawOverhead_old():
    fig = plt.figure(figsize=(10,1.5))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    
    getPerformance()
    vaultNormal = [float(b)/float(a) for a,b in zip(VaultCycle,VaultCycle)]
    preNoAesNormal = [float(b)/float(a) for a,b in zip(AllPreVaultCycle,VaultCycle)]
    AllNormal = [float(b)/float(a) for a,b in zip(PreVaultCycle,VaultCycle)]
    # vaultNormal = vaultOverhead
    # preNoAesNormal = preOverhead
    # AllNormal = AllpreOverhead
    addAvg(vaultNormal)
    addAvg(preNoAesNormal)
    addAvg(AllNormal)

    print(vaultNormal)
    print(preNoAesNormal)
    print(AllNormal)

    w = 0.2
    xw1 = [a - w for a in x_w]
    xw2 = [a for a in x_w]
    xw3 = [a + w for a in x_w]
    l1 = ax.bar(xw1,vaultNormal,width=w, color = 'white',ec='k',lw=1.5)
    l2 = ax.bar(xw2,preNoAesNormal,width=w, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = ax.bar(xw3,AllNormal,width=w, color = rgb_limit0[1],ec='k',lw=1.5)

    case_full.append('Avg.')
    ax.set_xticks(x_w,case_full,rotation=35,fontsize=8, horizontalalignment='right')
    ax.set_ylabel('Nromalized\nPerformance',fontsize=12)
    ax.set_ylim(0.9,1.3)
    ax.set_xlim(-0.5,len(case)+0.5)
    ax.tick_params(labelsize=12)
    l11 = ax.legend((l1,l2,l3),['VAULT','PreSIT','PreSIT-OTPB'],
        loc='upper right',bbox_to_anchor=(0.55,1),ncol=3,fontsize=11)
    ax.add_artist(l11)

    # plt.yticks([0.7,0.8,0.9,1.0,1.1,1.2,1.3])
    plt.yticks([0.9,1.0,1.1,1.2,1.3])

    # plt.arrow(0,0.1,11,0,length_includes_head = True,head_width = 0.25,head_length = 0.5)

    # line_2 = plt.plot(x,y1,color='red',linewidth=1,linestyle='->',label='down')
    # fig.text(0.5, 0, 'x', ha='center')
    # ax.annotate('', xy=(0, -0.1), xytext=(0.6, -0.1),xycoords='axes fraction', va="center",  ha="center",arrowprops=dict(arrowstyle='<|-|>',facecolor='black'))
    # ax.annotate('', xy=(0.6, -0.1), xytext=(0.94, -0.1),xycoords='axes fraction', va="center",  ha="center",arrowprops=dict(arrowstyle='<|-|>',facecolor='black'))
    # ax.text(4.2, 0.35, 'SPEC', bbox=dict(fc="0.8"))
    # ax.text(13, 0.35, 'GAP', bbox=dict(fc="0.8"))

    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")
    plt.savefig('normalPer.pdf',dpi=600, bbox_inches='tight')
    plt.show()

def drawOverhead():
    fig = plt.figure(figsize=(10,2.8))
    ax = plt.gca()
    # last version 
    x_w = range(0,len(case)+3)
    # x_w = range(0,len(case)+5)
    
    getPerformance()
    vaultNormal = [float(b)/float(a) for a,b in zip(VaultCycle,VaultCycle)]
    preNoAesNormal = [float(b)/float(a) for a,b in zip(AllPreVaultCycle,VaultCycle)]
    AllNormal = [float(b)/float(a) for a,b in zip(PreVaultCycle,VaultCycle)]
    # vaultNormal = vaultOverhead
    # preNoAesNormal = preOverhead
    # AllNormal = AllpreOverhead
    addAvg(vaultNormal)
    addAvg(preNoAesNormal)
    addAvg(AllNormal)

    ##########R.1
    ALL_SPEC_GAP_AVG = 0
    PRENO_SPEC_GAP_AVG = 0
    for i in range(17):
        ALL_SPEC_GAP_AVG = ALL_SPEC_GAP_AVG + AllNormal[i]
        PRENO_SPEC_GAP_AVG = PRENO_SPEC_GAP_AVG + preNoAesNormal[i]
    ALL_SPEC_GAP_AVG = ALL_SPEC_GAP_AVG / 17
    PRENO_SPEC_GAP_AVG = PRENO_SPEC_GAP_AVG / 17
    print("General benchmarks: " + str(ALL_SPEC_GAP_AVG))
    print("General benchmarks (no AES): " + str(PRENO_SPEC_GAP_AVG))

    ALL_HPC_AVG = 0
    PRENO_HPC_AVG = 0
    for i in range(8):
        ALL_HPC_AVG = ALL_HPC_AVG + AllNormal[i+17]
        PRENO_HPC_AVG = PRENO_HPC_AVG + preNoAesNormal[i+17]
    ALL_HPC_AVG = ALL_HPC_AVG / 8
    PRENO_HPC_AVG = PRENO_HPC_AVG / 8
    print("HPC benchmarks: " + str(ALL_HPC_AVG))
    print("HPC benchmarks (no AES): " + str(PRENO_HPC_AVG))

    specAvg = 0
    gapAvg = 0
    parsecAvg = 0
    splash2xAvg = 0

    noA_specAvg = 0
    noA_gapAvg = 0
    noA_parsecAvg = 0
    noA_splash2xAvg = 0
    for i in range(11):
        specAvg = specAvg + AllNormal[i]
        noA_specAvg = noA_specAvg + preNoAesNormal[i]

    for i in range(6):
        gapAvg = gapAvg + AllNormal[i+11]
        noA_gapAvg = noA_gapAvg + preNoAesNormal[i+11]

    for i in range(5):
        parsecAvg = parsecAvg + AllNormal[i+17]
        noA_parsecAvg= noA_parsecAvg + preNoAesNormal[i+17]

    for i in range(3):
        splash2xAvg = splash2xAvg + AllNormal[i+22]
        noA_splash2xAvg= noA_splash2xAvg + preNoAesNormal[i+22]
    specAvg = specAvg/11
    noA_specAvg = noA_specAvg/11
    gapAvg = gapAvg/6
    noA_gapAvg = noA_gapAvg/6
    parsecAvg = parsecAvg/5
    noA_parsecAvg = noA_parsecAvg/5
    splash2xAvg = splash2xAvg / 3
    noA_splash2xAvg = noA_splash2xAvg / 3
    print("Impr. 4 benchmarks: "+str(specAvg)+" "+str(gapAvg)+" "+str(parsecAvg)+" "+str(splash2xAvg))
    print("NoAesImpr. 4 benchmarks: "+str(noA_specAvg)+" "+str(noA_gapAvg)+" "+str(noA_parsecAvg)+" "+str(noA_splash2xAvg))

    
    # last version
    vaultNormal.insert(24,1)
    vaultNormal.insert(25,1)

    preNoAesNormal.insert(25,PRENO_SPEC_GAP_AVG)
    preNoAesNormal.insert(26,PRENO_HPC_AVG)

    AllNormal.insert(25,ALL_SPEC_GAP_AVG)
    AllNormal.insert(26,ALL_HPC_AVG)

    case_forP.insert(25,"Avg.Gen")
    case_forP.insert(26,"Avg.HPC")
    

    '''
    vaultNormal.insert(24,1)
    vaultNormal.insert(25,1)
    vaultNormal.insert(26,1)
    vaultNormal.insert(27,1)

    preNoAesNormal.insert(25,noA_specAvg)
    preNoAesNormal.insert(26,noA_gapAvg)
    preNoAesNormal.insert(27,noA_parsecAvg)
    preNoAesNormal.insert(28,noA_splash2xAvg)

    AllNormal.insert(25,specAvg)
    AllNormal.insert(26,gapAvg)
    AllNormal.insert(27,parsecAvg)
    AllNormal.insert(28,splash2xAvg)

    case_forP.insert(25,"SPEC")
    case_forP.insert(26,"GAP")
    case_forP.insert(27,"PARSEC")
    case_forP.insert(28,"SPLASH")
    case_forP[-1] = "Overall"
    '''

    print(vaultNormal)
    print(preNoAesNormal)
    print(AllNormal)

    w = 0.2
    xw1 = [a - w for a in x_w]
    xw2 = [a for a in x_w]
    xw3 = [a + w for a in x_w]
    l1 = ax.bar(xw1,vaultNormal,width=w, color = 'white',ec='k',lw=1.5)
    l2 = ax.bar(xw2,preNoAesNormal,width=w, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = ax.bar(xw3,AllNormal,width=w, color = rgb_limit0[1],ec='k',lw=1.5)

    '''
    plt.vlines(xw1[-5]-0.3,ymin = 0, ymax=1.25, linewidth=1.5)
    plt.text(xw1[-3],1.22,'Avg.',family='times new roman',bbox=dict(fc='white',ec='black', alpha=1,boxstyle='round') ,ha='center',fontsize=12)

    plt.vlines(xw1[11]-0.3,ymin = 0, ymax=1.25, linewidth=1.5)
    plt.text(xw1[5],1.22,'SPEC',family='times new roman',bbox=dict(fc='white',ec='black', alpha=1,boxstyle='round') ,ha='center',fontsize=12)

    plt.vlines(xw1[17]-0.3,ymin = 0, ymax=1.25, linewidth=1.5)
    plt.text(xw1[14],1.22,'GAP',family='times new roman',bbox=dict(fc='white',ec='black', alpha=1,boxstyle='round') ,ha='center',fontsize=12)

    plt.vlines(xw1[22]-0.3,ymin = 0, ymax=1.25, linewidth=1.5)
    plt.text(xw1[19]+0.1,1.22,'PARSEC',family='times new roman',bbox=dict(fc='white',ec='black', alpha=1, boxstyle='round') ,ha='center',fontsize=12)

    plt.text(xw1[23]+0.2,1.22,'SPLASH',family='times new roman',bbox=dict(fc='white',ec='black', alpha=1, boxstyle='round') ,ha='center',fontsize=12)

    case_full.append('Overall')
    '''

    ax.set_xticks(x_w,case_forP,rotation=65,fontsize=10)
    ax.set_ylabel('Nromalized Performance',fontsize=17)
    ax.set_ylim(0.95,1.25)
    ax.set_xlim(-0.5,len(case_forP)-0.5)
    ax.tick_params(labelsize=15)
    # l11 = ax.legend((l1,l2,l3),['VAULT','VAULT+PreSIT-Basic','VAULT+PreSIT'],
        # loc='upper right',bbox_to_anchor=(0.8,1),ncol=1,fontsize=12)
    l11 = ax.legend((l1,l2,l3),['VAULT','VAULT+PreSIT-Basic','VAULT+PreSIT'],
        loc='upper right',bbox_to_anchor=(1,1),ncol=1,fontsize=11)
    # ax.add_artist(l11)

    # plt.yticks([0.7,0.8,0.9,1.0,1.1,1.2,1.3])
    plt.yticks([0.95,1.0,1.05,1.1,1.15,1.2,1.25])

    # plt.arrow(0,0.1,11,0,length_includes_head = True,head_width = 0.25,head_length = 0.5)

    # line_2 = plt.plot(x,y1,color='red',linewidth=1,linestyle='->',label='down')
    # fig.text(0.5, 0, 'x', ha='center')
    # ax.annotate('', xy=(0, -0.1), xytext=(0.6, -0.1),xycoords='axes fraction', va="center",  ha="center",arrowprops=dict(arrowstyle='<|-|>',facecolor='black'))
    # ax.annotate('', xy=(0.6, -0.1), xytext=(0.94, -0.1),xycoords='axes fraction', va="center",  ha="center",arrowprops=dict(arrowstyle='<|-|>',facecolor='black'))
    # ax.text(4.2, 0.35, 'SPEC', bbox=dict(fc="0.8"))
    # ax.text(13, 0.35, 'GAP', bbox=dict(fc="0.8"))

    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")
    plt.savefig('normalPer.pdf',dpi=600, bbox_inches='tight')
    plt.show()


def drawLat():
    # plt.figure(figsize=(10,2.1))
    fig = plt.figure(figsize=(10,2.1))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    
    getPerformance()

    addAvg(vaultReadL)
    addAvg(preNoAesReadL)
    addAvg(allReadL)

    print(vaultReadL)
    print(preNoAesReadL)
    print(allReadL)

    w = 0.2
    xw1 = [a - w for a in x_w]
    xw2 = [a for a in x_w]
    xw3 = [a + w for a in x_w]
    l1 = ax.bar(xw1,vaultReadL,width=w, color = 'white',ec='k',lw=1.5)
    l2 = ax.bar(xw2,preNoAesReadL,width=w, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = ax.bar(xw3,allReadL,width=w, color = rgb_limit0[1],ec='k',lw=1.5)
    print("Avg lat descent: "+str(vaultReadL[-1]-preNoAesReadL[-1])+" "+str(vaultReadL[-1]-allReadL[-1]))

    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=45,fontsize=14)
    ax.set_ylabel('Memory\nReading Lat. (ns)',fontsize=17)
    ax.set_ylim(50,135)
    ax.set_yticks([50,60,70,80,90,100,110,120,130])
    ax.set_xlim(-3*w,len(case)-w)
    ax.tick_params(labelsize=17)
    l11 = ax.legend((l1,l2,l3),['VAULT','VAULT+PreSIT-Basic','VAULT+PreSIT'],
        loc='upper right',bbox_to_anchor=(0.95,1.02),ncol=3,fontsize=11)

    # plt.yticks([0.7,0.8,0.9,1.0,1.1,1.2,1.3])


    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")
    plt.savefig('latency.pdf',dpi=600, bbox_inches='tight')
    plt.show()

def drawChit():
    # plt.figure(figsize=(10,2.1))
    fig = plt.figure(figsize=(10,1.5))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    
    getPerformance()
    
    aa = [a*100 for a in cntHitRate]
    bb = [a*100 for a in macHitRate]

    addAvg(aa)
    addAvg(bb)

    print(aa)
    print(bb)

    w = 0.25
    xw1 = [a - w/2 for a in x_w]
    xw3 = [a + w/2 for a in x_w]
    l1 = ax.bar(xw1,aa,width=w, color = rgb_limit0[0],ec='k',lw=1.5)
    l2 = ax.bar(xw3,bb,width=w, color = rgb_limit0[1],ec='k',lw=1.5)

    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=45,fontsize=17)
    ax.set_ylabel('Hit Rate (%)',fontsize=17)
    ax.set_ylim(0,100)
    ax.set_xlim(-2*w,len(case)-2*w)
    ax.tick_params(labelsize=17)
    l11 = ax.legend((l1,l2),['Counter','MAC'],
        loc='upper right',bbox_to_anchor=(0.7,1.4),ncol=2,fontsize=13)
    # ax.add_artist(l11)

    plt.yticks([0,25,50,75,100])


    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")
    plt.savefig('Chit.pdf',dpi=600, bbox_inches='tight')
    plt.show()

def drawTran():
    fig = plt.figure(figsize=(10,2))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    getPerformance()


    addAvg(Cnt0Tran)
    addAvg(DataTran)
    addAvg(Cnt1Tran)
    addAvg(CntHTran)
    addAvg(MacAll)
    addAvg(CntAll)
    addAvg(overflowTran)
    addAvg(prefetchTran)


    CntAllPer = [a/b for a,b in zip(CntAll,DataTran)]
    MacAllPer = [a/b for a,b in zip(MacAll,DataTran)]
    DataTranPer = [a/b for a,b in zip(DataTran,DataTran)]
    overflowTranPer = [a/b for a,b in zip(overflowTran,DataTran)]
    prefetchTranPer = [a/b for a,b in zip(prefetchTran,DataTran)]

    print(MacAllPer)
    print(CntAllPer)
    print(prefetchTranPer)
    print(overflowTranPer)
    print(DataTranPer)

    print("MAC and counters: "+str(MacAllPer[-1]+CntAllPer[-1]))

    bot0 = DataTranPer
    bot1 = np.add(bot0,prefetchTranPer)
    bot2 = np.add(bot1,MacAllPer)
    bot3 = np.add(bot2,CntAllPer)

    xw1 = [a for a in x_w]
    w = 0.45
    l1 = ax.bar(xw1,DataTranPer,width=w, color = rgb_limit0[0],ec='k',lw=1)
    l2 = ax.bar(xw1,prefetchTranPer,width=w,color='white',hatch='\\'*3,ec='k',bottom = bot0,lw=1)
    l3 = ax.bar(xw1,MacAllPer,width=w, color = rgb_limit1[0],ec='k',bottom = bot1,lw=1)
    l4 = ax.bar(xw1,CntAllPer,width=w, color = rgb_limit1[1],ec='k',bottom = bot2,lw=1)
    # l5 = ax.bar(xw1,overflowTranPer,width=w, color = rgb_limit0[1],ec='k',bottom = bot3,lw=1)


    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=35,fontsize=15)
    ax.set_ylabel('Memory Access',fontsize=17)
    ax.set_ylim(0,3.7)
    ax.set_yticks([0,0.5,1,1.5,2,2.5,3,3.5])
    ax.set_xlim(-w,len(case)-w)
    ax.tick_params(labelsize=14)

    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)

    l11 = ax.legend((l1,l2,l3,l4),['Data','Prefetch','MAC','Counter'],
            loc='upper right',bbox_to_anchor=(0.9,1),ncol=2,fontsize=13)
    ax.add_artist(l11)

    ax.grid(linestyle = "--", axis="y")
    plt.savefig('traffic.pdf',dpi=600, bbox_inches='tight')
    plt.show()


def drawPrefetchCycle():
    fig = plt.figure(figsize=(10,2.5))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    getPerformance()


    addAvg(prefetchLat)
    addAvg(GAPMem)
    addAvg(remainHash)
    print(prefetchLat)
    print(GAPMem)
    print(remainHash)

    w = 0.35
    xw1 = [a-w/2 for a in x_w]
    xw2 = [a+w/2 for a in x_w]
    l1 = ax.bar(xw1,prefetchLat,width=w, color = rgb_limit0[0], ec='k',lw=1)
    l2 = ax.bar(xw2,remainHash,width=w, color = 'white',hatch='\\'*2, ec='k',lw=1)
    # l3 = ax.bar(xw2,GAPMem,width=w, color = 'white', bottom=remainHash,ec='k',lw=1)
    i = 0
    for x,y,z in zip(xw2,remainHash,GAPMem):
        plt.text(x+0,y+0.01,'+',family='times new roman',ha='center',fontsize=13)
        if i == len(xw2)-1:
            plt.text(x,y+2,str(int(z)),family='times new roman',ha='center',fontsize=10)
        else:
            plt.text(x+0.145,y+2,str(int(z)),family='times new roman',ha='center',fontsize=10)
        i=i+1



    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=45,fontsize=14)
    ax.set_ylabel('Average Lat. (ns)',fontsize=17)
    ax.set_ylim(10,45)
    ax.set_yticks([10,20,30,40])
    ax.set_xlim(-w*2,len(case)-w)
    ax.tick_params(labelsize=17)

    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)

    l11 = ax.legend((l1,l2),['Prefetch','Spare in P.4 + GAP', 'GAP'],
        loc='upper right',bbox_to_anchor=(0.8,1.25),ncol=4,fontsize=14)

    ax.grid(linestyle = "--", axis="y")
    plt.savefig('PFC.pdf',dpi=600, bbox_inches='tight')
    plt.show()



def drawPThit():
    # plt.figure(figsize=(10,2.1))
    fig = plt.figure(figsize=(10,2.4))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    
    getPerformance()
    
    addAvg(prefetchFullRate)
    addAvg(prefetchWaitRate)
    addAvg(prefetchTreeRate)
    addAvg(AESRate)

    print(prefetchFullRate)
    print(prefetchWaitRate)
    print(prefetchTreeRate)
    print(AESRate)

    bot1 = np.add(prefetchWaitRate,prefetchFullRate)

    w = 0.25
    xw1 = [a - w/2 for a in x_w]
    xw3 = [a + w/2 for a in x_w]
    l1 = ax.bar(xw1,prefetchFullRate,width=w, color = 'white',hatch='\\'*3,ec='k',lw=1.5)
    l2 = ax.bar(xw1,prefetchWaitRate,width=w, color = 'white', bottom=prefetchFullRate,ec='k',lw=1.5)
    l3 = ax.bar(xw1,prefetchTreeRate,width=w, color = rgb_limit1[1], bottom=bot1,ec='k',lw=1.5)
    # l3 = ax.bar(xw3,AESRate,width=w, color = rgb_limit0[0],ec='k',lw=1.5)
    l4 = ax.bar(xw3,AESRate,width=w, color = rgb_limit0[0],ec='k',lw=1.5)


    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=45,fontsize=14)
    ax.set_ylabel('Prediction Rate (%)',fontsize=17)
    ax.set_ylim(0,65)
    ax.set_yticks([0,10,20,30,40,50,60])
    ax.set_xlim(-2*w,len(case)-2*w)
    ax.tick_params(labelsize=17)

    # plt.yticks([0.1,0.2,0.3,0.4,0.5])


    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")

    l11 = ax.legend((l1,l2,l3,l4),['RB (MAC Ready)','RB (MAC Wait)', 'RB (Counter Verify)', 'OTPB'],
        loc='upper right',bbox_to_anchor=(1,1.25),ncol=4,fontsize=13)
    # ax.add_artist(l11)

    plt.savefig('PThit.pdf',dpi=600, bbox_inches='tight')
    plt.show()


def drawPReduce():
    # plt.figure(figsize=(10,2.1))
    fig = plt.figure(figsize=(10,3))
    ax = plt.gca()
    ax2 = ax.twinx()
    x_w = range(0,len(case)+1)
    
    getPerformance()
    
    addAvg(saveAES)
    addAvg(SaveMAC)
    addAvg(saveAESOTPB)
    addAvg(successPerAll)
    addAvg(successPerAllOTPB)
    addAvg(PrePer)

    print(saveAES)
    print(saveAESOTPB)
    print(SaveMAC)

    print(successPerAll)
    print(successPerAllOTPB)
    print(PrePer)

    w = 0.3
    xw1 = [a - w/2 for a in x_w]
    xw3 = [a + w/2 for a in x_w]
    l1 = ax.bar(xw1,saveAES,width=w, color = 'white',hatch = '\\'*2,ec='k',lw=1.5)
    l2= ax.bar(xw1,saveAESOTPB,width=w, color ='white',bottom=saveAES, ec='k',lw=1.5)
    l3 = ax.bar(xw3,SaveMAC,width=w, color = rgb_limit0[0],ec='k',lw=1.5)

    l4 = ax2.plot(xw1,successPerAll, color='black',marker='s',markersize=6,markerfacecolor='white',linestyle='--',lw=1.2)
    l5 = ax2.plot(xw1,successPerAllOTPB, color='black',marker='o',markersize=5,markerfacecolor='black',linestyle='--',lw=1.2)

    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=45,fontsize=14)
    ax.set_ylabel('Computation\nTime Reduction (%)',fontsize=17)
    ax.set_ylim(0,80)
    ax.set_yticks([0,10,20,30,40,50,60,70,80])
    ax.set_xlim(-2*w,len(case)-2*w)
    ax.tick_params(labelsize=17)

    # plt.yticks([0.1,0.2,0.3,0.4,0.5])
    ax2.set_ylabel('Hit Rate (%)',fontsize=17)
    ax2.set_ylim(0,35)
    ax2.tick_params(labelsize=17)


    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")

    l11 = ax.legend((l1,l2,l3),['OTP in RB','OTP in OTP-O','MAC'],
        loc='upper right',bbox_to_anchor=(0.68,1.33),ncol=3,fontsize=14, title='Y-Left', title_fontsize=15)
    l22 = ax2.legend(['RB','OTPB'],
        loc='upper right',bbox_to_anchor=(1.03,1.33),ncol=2,fontsize=14, title='Y-Right', title_fontsize=15)

    plt.savefig('PReduce.pdf',dpi=600, bbox_inches='tight')
    plt.show()


def drawAverPal():
    # plt.figure(figsize=(10,2.1))
    fig = plt.figure(figsize=(10,3))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    
    getPerformance()
    
    addAvg(P1Avg)
    addAvg(P3Avg)
    addAvg(P4Avg)

    print(P1Avg)
    print(P3Avg)
    print(P4Avg)

    w = 0.2
    xw1 = [a - w for a in x_w]
    xw2 = [a for a in x_w]
    xw3 = [a + w for a in x_w]
    l1 = ax.bar(xw1,P1Avg,width=w, color ='white', hatch = '\\'*2,ec='k',lw=1.5)
    l2 = ax.bar(xw2,P3Avg,width=w, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = ax.bar(xw3,P4Avg,width=w, color = rgb_limit0[1],ec='k',lw=1.5)

    case.append('Avg.')
    ax.set_xticks(x_w,case,rotation=35,fontsize=17)
    ax.set_ylabel('Average Lat. (ns)',fontsize=19)
    ax.set_ylim(0,55)
    ax.set_yticks([1,10,20,30,40,50])
    ax.set_xlim(-w*3,len(case)-2*w)
    ax.tick_params(labelsize=17)

    # plt.yticks([0.1,0.2,0.3,0.4,0.5])


    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")

    l11 = ax.legend((l1,l2,l3),['P1 Avg.','P3 Hidden Avg.','P4 Hidden Avg.'],
        loc='upper right',bbox_to_anchor=(0.9,1.24),ncol=3,fontsize=15)

    plt.savefig('ParallelLat.pdf',dpi=600, bbox_inches='tight')
    plt.show()

def drawPTparam():
    # plt.figure(figsize=(10,2.1))
    # fig = plt.figure(figsize=(10,3.5))
    # ax = plt.gca()
    # x_w = range(0,len(case)+1)

    w = 12
    fig,axs = plt.subplots(2,1,figsize=(10,3),dpi=100,sharex='col',constrained_layout=True)
    
    getPerformance(alen=True,PTen=True)

    addAvg(OverheadGroup4)
    addAvg(PrResGroup4 )
    addAvg(PrOTPBGroup4)
    addAvg(OverheadGroup8)
    addAvg(PrResGroup8)
    addAvg(PrOTPBGroup8)
    addAvg(OverheadGroup16)
    addAvg(PrResGroup16)
    addAvg(PrOTPBGroup16)
    addAvg(OverheadEntry4)
    addAvg(PrResEntry4)
    addAvg(PrOTPBEntry4)
    addAvg(OverheadEntry6)
    addAvg(PrResEntry6)
    addAvg(PrOTPBEntry6)
    addAvg(OverheadEntry8)
    addAvg(PrResEntry8)
    addAvg(PrOTPBEntry8)

    OverheadGroup4_avg = OverheadGroup4[len(case)]
    OverheadGroup8_avg = OverheadGroup8[len(case)]
    OverheadGroup16_avg = OverheadGroup16[len(case)]
    PrResGroup4_avg = PrResGroup4[len(case)]
    PrResGroup8_avg = PrResGroup8[len(case)]
    PrResGroup16_avg = PrResGroup16[len(case)]
    PrOTPBGroup4_avg = PrOTPBGroup4[len(case)]
    PrOTPBGroup8_avg = PrOTPBGroup8[len(case)]
    PrOTPBGroup16_avg = PrOTPBGroup16[len(case)]

    OverheadEntry4_avg = OverheadEntry4[len(case)]
    OverheadEntry6_avg = OverheadEntry6[len(case)]
    OverheadEntry8_avg = OverheadEntry8[len(case)]
    PrResEntry4_avg = PrResEntry4[len(case)]
    PrResEntry6_avg = PrResEntry6[len(case)]
    PrResEntry8_avg = PrResEntry8[len(case)]
    PrOTPBEntry4_avg = PrOTPBEntry4[len(case)]
    PrOTPBEntry6_avg = PrOTPBEntry6[len(case)]
    PrOTPBEntry8_avg = PrOTPBEntry8[len(case)]

    wi = 0.4
    axs01 = axs[0].twinx()
    l1 = axs[0].bar(1-wi,OverheadGroup4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs[0].bar(1,OverheadGroup8_avg,width=wi, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs[0].bar(1+wi,OverheadGroup16_avg,width=wi, color = rgb_limit0[1],ec='k',lw=1.5)
   
    l1 = axs01.bar(3-wi,PrResGroup4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs01.bar(3,PrResGroup8_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs01.bar(3+wi,PrResGroup16_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    l1 = axs01.bar(5-wi,PrOTPBGroup4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs01.bar(5,PrOTPBGroup8_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs01.bar(5+wi,PrOTPBGroup16_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    print("Gourp8 + 4 Entry: "+str(PrResGroup8_avg)+" "+str(PrOTPBGroup8_avg))
    print("Gourp8 + 6 Entry: "+str(PrResEntry6_avg)+" "+str(PrOTPBEntry6_avg))
    print("Gourp8 + 8 Entry: "+str(PrResEntry8_avg)+" "+str(PrOTPBEntry8_avg))
    print("Gourp4 + 4 Entry: "+str(PrResGroup4_avg)+" "+str(PrOTPBGroup4_avg))
    print("Gourp16 + 4 Entry: "+str(PrResGroup16_avg)+" "+str(PrOTPBGroup16_avg))

    axs[0].set_xlim(0,6)
    axs[0].set_ylim(1.03,1.08) 
    axs[0].set_yticks([1.03,1.04,1.05,1.06,1.07,1.08])
    axs01.set_ylim(15,40)
    axs01.set_yticks([15,20,25,30,35,40])
    # x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    axs[0].set_xticks([1,3,5],['Performance (Y-Left)','RB (Y-Right)','OTPB (Y-Right)'],rotation=30,fontsize=20)
    axs[0].set_ylabel('Entry4\nNor. Per.',fontsize=16,color='black')
    axs01.set_ylabel('Prediction\nRate (%)',fontsize=16,color='black')
    axs[0].spines['bottom'].set_linewidth(1.5)
    axs01.spines['bottom'].set_linewidth(1.5)
    axs[0].spines['top'].set_linewidth(1.5)
    axs[0].spines['left'].set_linewidth(1.5)
    axs[0].spines['right'].set_linewidth(1.5)

    l11 = axs[0].legend((l1,l2,l3),['Group4','Group8','Group16'],
            loc='upper right',bbox_to_anchor=(0.71,1.48),ncol=3,fontsize=13)
    # axs[0].add_artist(l11)
    axs[0].grid(linestyle = ":")
    # axs01.grid(linestyle = ":")
    axs[0].tick_params(labelsize=17)
    axs01.tick_params(labelsize=17)


    wi = 0.4
    axs11 = axs[1].twinx()
    l1 = axs[1].bar(1-wi,OverheadEntry4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs[1].bar(1,OverheadEntry6_avg,width=wi, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs[1].bar(1+wi,OverheadEntry8_avg,width=wi, color = rgb_limit0[1],ec='k',lw=1.5)
   
    l1 = axs11.bar(3-wi,PrResEntry4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs11.bar(3,PrResEntry6_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs11.bar(3+wi,PrResEntry8_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    l1 = axs11.bar(5-wi,PrOTPBEntry4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs11.bar(5,PrOTPBEntry6_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs11.bar(5+wi,PrOTPBEntry8_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    axs[1].set_xlim(0,6)
    axs[1].set_ylim(1.03,1.08) 
    axs[1].set_yticks([1.03,1.04,1.05,1.06,1.07,1.08])
    axs11.set_ylim(15,40)
    axs11.set_yticks([15,20,25,30,35,40])
    # x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    # axs[1].set_xticks([1,3,5],['Performance (Y-Left)','Resulst Buffer (Y-Right)','OTPB (Y-Right)'],rotation=30,fontsize=17)
    axs[1].set_ylabel('Group8\nNor. Per.',fontsize=17,color='black')
    axs11.set_ylabel('Prediction\nRate (%)',fontsize=17,color='black')
    axs[1].spines['bottom'].set_linewidth(1.5)
    axs11.spines['bottom'].set_linewidth(1.5)
    axs[1].spines['top'].set_linewidth(1.5)
    axs[1].spines['left'].set_linewidth(1.5)
    axs[1].spines['right'].set_linewidth(1.5)

    l11 = axs[1].legend((l1,l2,l3),['Entry4','Entry6','Entry8'],
            loc='upper right',bbox_to_anchor=(0.71,1.48),ncol=3,fontsize=13)
    # axs[1].add_artist(l11)
    axs[1].grid(linestyle = ":")
    axs11.grid(linestyle = ":")
    axs01.grid(linestyle = ":")
    axs[1].tick_params(labelsize=16)
    axs11.tick_params(labelsize=16)

    plt.subplots_adjust(left=None,bottom=None,right=None,top=None,wspace=0.2,hspace=0.1)
    plt.savefig('PTparam.pdf',dpi=600, bbox_inches='tight')


    plt.show()

def drawPTparam_1():
    # plt.figure(figsize=(10,2.1))
    # fig = plt.figure(figsize=(10,3.5))
    # ax = plt.gca()
    # x_w = range(0,len(case)+1)

    w = 12
    fig,axs = plt.subplots(1,2,figsize=(6,3),dpi=100,sharey='row',constrained_layout=True)
    
    getPerformance(alen=True,PTen=True)

    addAvg(OverheadGroup4)
    addAvg(PrResGroup4 )
    addAvg(PrOTPBGroup4)
    addAvg(OverheadGroup8)
    addAvg(PrResGroup8)
    addAvg(PrOTPBGroup8)
    addAvg(OverheadGroup16)
    addAvg(PrResGroup16)
    addAvg(PrOTPBGroup16)
    addAvg(OverheadEntry4)
    addAvg(PrResEntry4)
    addAvg(PrOTPBEntry4)
    addAvg(OverheadEntry6)
    addAvg(PrResEntry6)
    addAvg(PrOTPBEntry6)
    addAvg(OverheadEntry8)
    addAvg(PrResEntry8)
    addAvg(PrOTPBEntry8)

    OverheadGroup4_avg = OverheadGroup4[len(case)]
    OverheadGroup8_avg = OverheadGroup8[len(case)]
    OverheadGroup16_avg = OverheadGroup16[len(case)]
    PrResGroup4_avg = PrResGroup4[len(case)]
    PrResGroup8_avg = PrResGroup8[len(case)]
    PrResGroup16_avg = PrResGroup16[len(case)]
    PrOTPBGroup4_avg = PrOTPBGroup4[len(case)]
    PrOTPBGroup8_avg = PrOTPBGroup8[len(case)]
    PrOTPBGroup16_avg = PrOTPBGroup16[len(case)]

    OverheadEntry4_avg = OverheadEntry4[len(case)]
    OverheadEntry6_avg = OverheadEntry6[len(case)]
    OverheadEntry8_avg = OverheadEntry8[len(case)]
    PrResEntry4_avg = PrResEntry4[len(case)]
    PrResEntry6_avg = PrResEntry6[len(case)]
    PrResEntry8_avg = PrResEntry8[len(case)]
    PrOTPBEntry4_avg = PrOTPBEntry4[len(case)]
    PrOTPBEntry6_avg = PrOTPBEntry6[len(case)]
    PrOTPBEntry8_avg = PrOTPBEntry8[len(case)]

    wi = 0.4
    axs01 = axs[0].twinx()
    l1 = axs[0].bar(1-wi,OverheadGroup4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs[0].bar(1,OverheadGroup8_avg,width=wi, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs[0].bar(1+wi,OverheadGroup16_avg,width=wi, color = rgb_limit0[1],ec='k',lw=1.5)
   
    l1 = axs01.bar(3-wi,PrResGroup4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs01.bar(3,PrResGroup8_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs01.bar(3+wi,PrResGroup16_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    l1 = axs01.bar(5-wi,PrOTPBGroup4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs01.bar(5,PrOTPBGroup8_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs01.bar(5+wi,PrOTPBGroup16_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    axs[0].set_xlim(0,6)
    axs[0].set_ylim(1.05,1.1) 
    axs[0].set_yticks([1.05,1.06,1.07,1.08,1.09,1.1])
    axs01.set_ylim(15,40)
    # axs01.set_yticks([15,20,25,30,35,40])
    axs01.axis('off')
    # x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    axs[0].set_xticks([1,3,5],['Performance (Y-Left)','RB (Y-Right)','OTPB (Y-Right)'],rotation=30,fontsize=12)
    axs[0].set_ylabel('Nor. Performance',fontsize=16,color='black')
    # axs01.set_ylabel('Prediction Rate (%)',fontsize=16,color='black')
    axs[0].spines['bottom'].set_linewidth(1.5)
    axs01.spines['bottom'].set_linewidth(1.5)
    axs[0].spines['top'].set_linewidth(1.5)
    axs[0].spines['left'].set_linewidth(1.5)
    axs[0].spines['right'].set_linewidth(1.5)

    l11 = axs[0].legend((l1,l2,l3),['Group4','Group8','Group16'],
            loc='upper right',bbox_to_anchor=(0.75,1.38),ncol=3,fontsize=15)
    # axs[0].add_artist(l11)
    axs[0].grid(linestyle = ":")
    # axs01.grid(linestyle = ":")
    axs[0].tick_params(labelsize=17)
    axs01.tick_params(labelsize=17)


    wi = 0.4
    axs11 = axs[1].twinx()
    l1 = axs[1].bar(1-wi,OverheadEntry4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs[1].bar(1,OverheadEntry6_avg,width=wi, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs[1].bar(1+wi,OverheadEntry8_avg,width=wi, color = rgb_limit0[1],ec='k',lw=1.5)
   
    l1 = axs11.bar(3-wi,PrResEntry4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs11.bar(3,PrResEntry6_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs11.bar(3+wi,PrResEntry8_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    l1 = axs11.bar(5-wi,PrOTPBEntry4_avg,width=wi, color ='white',ec='k',lw=1.5)
    l2 = axs11.bar(5,PrOTPBEntry6_avg,width=wi, color =rgb_limit0[0],ec='k',lw=1.5)
    l3 = axs11.bar(5+wi,PrOTPBEntry8_avg,width=wi, color =rgb_limit0[1],ec='k',lw=1.5)

    axs[1].set_xlim(0,6)
    axs[1].set_ylim(1.05,1.10) 
    axs[1].set_yticks([1.05,1.06,1.07,1.08,1.09,1.1])
    axs11.set_ylim(15,40)
    axs11.set_yticks([15,20,25,30,35,40])
    # x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    axs[1].set_xticks([1,3,5],['Performance (Y-Left)','Resulst Buffer (Y-Right)','OTPB (Y-Right)'],rotation=30,fontsize=12)
    # axs[1].set_ylabel('Nor. Performance',fontsize=16,color='black')
    axs11.set_ylabel('Prediction Rate (%)',fontsize=16,color='black')
    axs[1].spines['bottom'].set_linewidth(1.5)
    axs11.spines['bottom'].set_linewidth(1.5)
    axs[1].spines['top'].set_linewidth(1.5)
    axs[1].spines['left'].set_linewidth(1.5)
    axs[1].spines['right'].set_linewidth(1.5)

    l11 = axs[1].legend((l1,l2,l3),['Entry4','Entry6','Entry8'],
            loc='upper right',bbox_to_anchor=(0.71,1.38),ncol=3,fontsize=15)
    # axs[1].add_artist(l11)
    axs[1].grid(linestyle = ":")
    axs11.grid(linestyle = ":")
    axs01.grid(linestyle = ":")
    axs[1].tick_params(labelsize=17)
    axs11.tick_params(labelsize=17)

    plt.subplots_adjust(left=None,bottom=None,right=None,top=None,wspace=0.2,hspace=0.1)
    plt.savefig('PTparam.pdf',dpi=600, bbox_inches='tight')


    plt.show()


def drawPDA():
    fig = plt.figure(figsize=(10,2.6))
    ax = plt.gca()
    x_w = range(0,len(case)+1)
    
    getPerformance(alen=True)
    vaultNormal = [float(b)/float(a) for a,b in zip(VaultCycle,VaultCycle)]
    PDANormal = [float(b)/float(a) for a,b in zip(PDACycle,VaultCycle)]
    APANormal = [float(b)/float(a) for a,b in zip(APACycle,VaultCycle)]
    AllNormal = [float(b)/float(a) for a,b in zip(PreVaultCycle,VaultCycle)]
    # vaultNormal = vaultOverhead
    # preNoAesNormal = preOverhead
    # AllNormal = AllpreOverhead
    addAvg(vaultNormal)
    addAvg(PDANormal)
    addAvg(APANormal)
    addAvg(AllNormal)

    print(vaultNormal)
    print(PDANormal)
    print(APANormal)
    print(AllNormal)

    w = 0.18
    xw1 = [a - w*1.5 for a in x_w]
    xw2 = [a - w*0.5 for a in x_w]
    xw3 = [a + w*0.5  for a in x_w]
    xw4 = [a + w*1.5 for a in x_w]
    l1 = ax.bar(xw1,vaultNormal,width=w, color = 'white',ec='k',lw=1.5)
    l2 = ax.bar(xw2,AllNormal,width=w, color = 'white',hatch='\\'*3,ec='k',lw=1.5)
    l3 = ax.bar(xw3,PDANormal,width=w, color = rgb_limit0[0],ec='k',lw=1.5)
    l4 = ax.bar(xw4,APANormal,width=w, color = rgb_limit0[1],ec='k',lw=1.5)

    case.append('Avg.')
    ax.set_xticks(x_w,case_forP,rotation=40,fontsize=10)
    ax.set_ylabel('Nor. Performance',fontsize=17)
    ax.set_ylim(0.9,1.25)
    ax.set_xlim(-0.5,len(case)-0.5)
    ax.tick_params(labelsize=15)
    l11 = ax.legend((l1,l2,l3,l4),['VAULT','VAULT+PreSIT','VAULT+PreSIT (no PDA)','VAULT+PreSIT (no APA)'],
        loc='upper right',bbox_to_anchor=(1,1),ncol=1,fontsize=11)
    ax.add_artist(l11)

    # plt.yticks([0.7,0.8,0.9,1.0,1.1,1.2,1.3])
    plt.yticks([0.9,0.95,1.0,1.05,1.1,1.15,1.2,1.25])

    # plt.arrow(0,0.1,11,0,length_includes_head = True,head_width = 0.25,head_length = 0.5)

    # line_2 = plt.plot(x,y1,color='red',linewidth=1,linestyle='->',label='down')
    # fig.text(0.5, 0, 'x', ha='center')
    # ax.annotate('', xy=(0, -0.1), xytext=(0.6, -0.1),xycoords='axes fraction', va="center",  ha="center",arrowprops=dict(arrowstyle='<|-|>',facecolor='black'))
    # ax.annotate('', xy=(0.6, -0.1), xytext=(0.94, -0.1),xycoords='axes fraction', va="center",  ha="center",arrowprops=dict(arrowstyle='<|-|>',facecolor='black'))
    # ax.text(4.2, 0.35, 'SPEC', bbox=dict(fc="0.8"))
    # ax.text(13, 0.35, 'GAP', bbox=dict(fc="0.8"))

    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")
    plt.savefig('noPredictAssisting.pdf',dpi=600, bbox_inches='tight')
    plt.show()

def drawCore():
    # fig = plt.figure(figsize=(5,3.5))
    # ax = plt.gca()
    
    getPerformance()
    vaultNormal_4core = [float(b)/float(a) for a,b in zip(Inst4coreVault,Inst4coreVault)]
    PreNoAesNormal_4core = [float(b)/float(a) for a,b in zip(Inst4coreVault,Inst4corePreNoAES)]
    PreNormal_4core = [float(b)/float(a) for a,b in zip(Inst4coreVault,Inst4corePre)]

    vaultNormal_2core = [float(b)/float(a) for a,b in zip(Inst2coreVault,Inst2coreVault)]
    PreNoAesNormal_2core = [float(b)/float(a) for a,b in zip(Inst2coreVault,Inst2corePreNoAES)]
    PreNormal_2core = [float(b)/float(a) for a,b in zip(Inst2coreVault,Inst2corePre)]

    vaultNormal_8gb = [float(b)/float(a) for a,b in zip(Vault8gb,Vault8gb)]
    preNor8gb = [float(b)/float(a) for a,b in zip(Pre8gb,Vault8gb)]

    vaultNormal_32gb = [float(b)/float(a) for a,b in zip(Vault32gb,Vault32gb)]
    preNor32gb = [float(b)/float(a) for a,b in zip(Pre32gb,Vault32gb)]

    basicNormal = [float(b)/float(a) for a,b in zip(PreVaultCycle,VaultCycle)]
    basicReadFreq = [a*1000/wholeInst for a in readReq]
    addAvg(PrResGroup8)
    addAvg(PrOTPBGroup8)
    addAvg(basicNormal)
    addAvg(basicReadFreq)

    addAvg(vaultNormal_4core)
    addAvg(PreNoAesNormal_4core)
    addAvg(PreNormal_4core)
    addAvg(vaultNormal_2core)
    addAvg(PreNoAesNormal_2core)
    addAvg(PreNormal_2core)

    addAvg(ReadingFreq2core)
    addAvg(ReadingFreq4core)

    #gb
    addAvg(vaultNormal_8gb)
    addAvg(preNor8gb)
    addAvg(vaultNormal_32gb)
    addAvg(preNor32gb)
    addAvg(ReadingFreq8gb)
    addAvg(ReadingFreq32gb)

    addAvg(PrRes32gb)
    addAvg(PrRes8gb)
    addAvg(PrRes4core)
    addAvg(PrRes2core)

    addAvg(PrOTPB32gb)
    addAvg(PrOTPB8gb)
    addAvg(PrOTPB4core)
    addAvg(PrOTPB2core)

    print(vaultNormal_4core)
    print(PreNoAesNormal_4core)
    print(PreNormal_4core)
    print(vaultNormal_2core)
    print(PreNoAesNormal_2core)
    print(PreNormal_2core)

    print("2 4 cores")
    print(PreNormal_2core[-1])
    print(ReadingFreq2core[-1])
    print(PreNormal_4core[-1])
    print(ReadingFreq4core[-1])

    print("8GB and 32GB")
    print(preNor8gb[-1])
    print(ReadingFreq8gb[-1])
    print(preNor32gb[-1])
    print(ReadingFreq32gb[-1])

    perList = [basicNormal[-1],PreNormal_2core[-1],PreNormal_4core[-1],preNor8gb[-1],preNor32gb[-1]]
    rfList = [basicReadFreq[-1], ReadingFreq2core[-1],ReadingFreq4core[-1],ReadingFreq8gb[-1],ReadingFreq32gb[-1]]
    rbList = [PrResGroup8[-1], PrRes2core[-1], PrRes4core[-1], PrRes8gb[-1], PrRes32gb[-1]]
    OTPBList = [PrOTPBGroup8[-1], PrOTPB2core[-1], PrOTPB4core[-1], PrOTPB8gb[-1], PrOTPB32gb[-1]]
    print(rbList)
    print(OTPBList)

    fig = plt.figure(figsize=(8,2))
    ax = plt.gca()
    ax2 = ax.twinx()
    case_print = ['16GB + 1core', '16GB + 2core', '16GB + 4core', '8GB + 1core', '32GB + 1core']

    w=0.5
    xw1 = [0,2,4,6,8]
    xw2 = [a + w for a in xw1]
    xw3 = [a + w for a in xw2]

    xw4 = [1,3,5,7]
    xw4 = [a + w for a in xw4]
    plt.vlines(xw4[0],ymin = 0, ymax=50)
    plt.vlines(xw4[1],ymin = 0, ymax=50)
    plt.vlines(xw4[2],ymin = 0, ymax=50)
    plt.vlines(xw4[3],ymin = 0, ymax=50)
    
    plt.text(xw3[0]-0.5,45,'Reading Freq. '+str(round(rfList[0],1)),family='times new roman',ha='center',fontsize=11)
    plt.text(xw3[1]-0.5,45,'Reading Freq. '+str(round(rfList[1],1)),family='times new roman',ha='center',fontsize=11)
    plt.text(xw3[2]-0.5,45,'Reading Freq. '+str(round(rfList[2],1)),family='times new roman',ha='center',fontsize=11)
    plt.text(xw3[3]-0.5,45,'Reading Freq. '+str(round(rfList[3],1)),family='times new roman',ha='center',fontsize=11)
    plt.text(xw3[4]-0.5,45,'Reading Freq. '+str(round(rfList[4],1)),family='times new roman',ha='center',fontsize=11)

    l1 = ax.bar(xw1,perList,width=w, color = 'white',ec='k',lw=1.5)

    l2= ax2.bar(xw2,rbList,width=w, color = rgb_limit0[0],ec='k',lw=1.5)
    l3 = ax2.bar(xw3,OTPBList,width=w, color = rgb_limit0[1],ec='k',lw=1.5)

    case.append('Avg.')
    ax.set_xticks(xw2,case_print,rotation=10,fontsize=10)
    ax.set_ylabel('Nor. Performance',fontsize=17)
    ax.set_ylim(1.03,1.08)
    ax.set_yticks([1.03,1.04,1.05,1.06,1.07,1.08])
    ax.set_xlim(-0.5,9.5)
    ax.tick_params(labelsize=15)

    ax2.set_ylim(0,50)
    ax2.set_yticks([0,10,20,30,40,50])
    ax2.tick_params(labelsize=15)
    ax2.set_ylabel('Prediction Rate %',fontsize=17)

    l11 = ax.legend((l1),['Nor. Performance',],
        loc='upper right',bbox_to_anchor=(0.5,1.37),ncol=1,fontsize=11, title = "Y-Left",title_fontsize = 11)
    l22 = ax2.legend((l2,l3),['RB', 'OTPB'],
        loc='upper right',bbox_to_anchor=(0.9,1.37),ncol=2,fontsize=11, title = "Y-Right",title_fontsize = 11)

    
    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.grid(linestyle = ":", axis="y")

    plt.savefig('cores.pdf',dpi=600, bbox_inches='tight')
    plt.show()

def printInstP():
    getPerformance()
    # addAvg(InstNum)
    # addAvg(LoadInsts)
    # addAvg(readReq)
    inum = []
    for i in range(25):
        inum.append(1000000000)


    perReadLoad = [float(a)/float(b) for a,b in zip(readReq,LoadInsts)]
    perLoadInst = [float(a)/float(b) for a,b in zip(LoadInsts,inum)]

    perReadLoadGeneral = perReadLoad[:16]
    perReadLoadHPC = perReadLoad[17:]

    perLoadInstGeneral = perLoadInst[:16]
    perLoadInstHPC = perLoadInst[17:]

    writeFreq = [a*1000/wholeInst for a in writeReq]
    readFreq = [a*1000/wholeInst for a in readReq]
    writeFreqGeneral = writeFreq[:16]
    writeFreqHPC = writeFreq[17:]
    readFreqGeneral = readFreq[:16]
    readFreqHPC = readFreq[17:]
    print("HPC Read Freq size is "+str(len(readFreqHPC)))

    addAvg(writeFreqGeneral)
    addAvg(readFreqGeneral)
    addAvg(writeFreqHPC)
    addAvg(readFreqHPC)


    addAvg(perReadLoadGeneral)
    addAvg(perReadLoadHPC)
    addAvg(perLoadInstGeneral)
    addAvg(perLoadInstHPC)

    print(perReadLoadGeneral)
    print(perReadLoadHPC)
    print(perLoadInstGeneral)
    print(perLoadInstHPC)

    print("perReadLoadGeneral " +str(perReadLoadGeneral[-1]))
    print("perReadLoadHPC "+ str(perReadLoadHPC[-1]))
    print("perLoadInstGeneral "+str(perLoadInstGeneral[-1]))
    print("perLoadInstHPC "+ str(perLoadInstHPC[-1]))

    print("writeFreqGeneral "+ str(writeFreqGeneral[-1]))
    print("readFreqGeneral " + str(readFreqGeneral[-1]))
    print("writeFreqHPC "+ str(writeFreqHPC[-1]))
    print("readFreqHPC " + str(readFreqHPC[-1]))
    
    # check = [float(a)*float(b)*1000 for a,b in zip(perLoadInstHPC,perReadLoadHPC)]
    # print(readFreqHPC)
    # print(check)

    # check = [float(a)*float(b)*1000 for a,b in zip(perLoadInstGeneral,perReadLoadGeneral)]
    # print(readFreqGeneral)
    # print(check)


toCaseName='525'
excel_mode = 0
i=0
drawContent=''
for line in sys.argv:
    if(line == "--CaseOverhead"):
        toCaseName=sys.argv[i+1]
        InstMode = True
    if(line == "--ecl1"):
        excel_mode=1
    if(line == "--draw"):
        drawContent=sys.argv[i+1]

    i+=1


file = open(fileName,'r')
lines = file.readlines()
dicFind = getLineEnc(lines)
res = Dic2List(dicFind)

# getPerformance('/home/wxrqw/res.xlsx')
getCaseOverhead(toCaseName)

if excel_mode == 1:
    getPerformance('res.xlsx')

if drawContent == "identify":
    drawOverheadIdentify()
elif drawContent == "overhead":
    drawOverhead()
elif drawContent == "lat":
    drawLat()
elif drawContent == "noTree":
    drawNoTree()
elif drawContent == "cacheHit":
    drawChit()
elif drawContent == "tran":
    drawTran()
elif drawContent == "PFC":
    drawPrefetchCycle()
elif drawContent == "PTHit":
    drawPThit()
elif drawContent == "reduce":
    drawPReduce()
elif drawContent == "Plat":
    drawAverPal()
elif drawContent == "PTParam":
    drawPTparam()
elif drawContent == "PDA":
    drawPDA()
elif drawContent == "core":
    drawCore()
elif drawContent == "InstP":
    printInstP()
# elif drawContent == "all":
#     drawPDA()
#     drawOverheadIdentify()
#     drawOverhead()
#     drawLat()
#     drawNoTree()
#     drawChit()
#     drawTran()
#     drawPrefetchCycle()
#     drawPThit()
#     drawPReduce()

